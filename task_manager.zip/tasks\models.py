from django.db import models
from django.contrib.auth.models import User



class Task(models.Model):
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('paused', 'Paused'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='owned_tasks', verbose_name="Владелец")
    assigned_users = models.ManyToManyField(User, blank=True, related_name='assigned_tasks', verbose_name="Назначенные пользователи")
    deadline = models.DateField(null=True, blank=True, verbose_name="Срок выполнения")

    pause_comment = models.TextField(null=True, blank=True, verbose_name="Комментарий к приостановке")
    resume_date = models.DateField(null=True, blank=True, verbose_name="Дата возобновления")
    is_paused = models.BooleanField(default=False)

    def __str__(self):
        return self.title



    status = models.CharField(max_length=20, choices=[
        ('open', 'Open'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ], default='open')

    def __str__(self):
        return self.title


class Order(models.Model):
    task = models.ForeignKey(Task, related_name='orders', on_delete=models.CASCADE)
    status = models.CharField(max_length=50)
    assigned_to = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Order for {self.task.title} - Status: {self.status}"