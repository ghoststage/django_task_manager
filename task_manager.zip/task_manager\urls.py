from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import redirect
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from tasks.views import RegisterView, LoginView, login_view, register_view  # Импортируем все необходимые представления
from django.contrib.auth.views import LogoutView



# Главная страница будет редиректить на страницу логина
def home(request):
    return redirect('login')  # Это редиректит на страницу с именем 'login'

urlpatterns = [
    path('', home, name='home'),  # Главная страница с редиректом
    path('admin/', admin.site.urls),  # Путь к админке
    path('login/', login_view, name='login'),  # Используем функцию login_view
    path('register/', register_view, name='register'),  # Используем функцию register_view
    path('tasks/', include('tasks.urls')),  # Путь к задачам (подключаем urls для задач)

    # Путь для получения и обновления токенов JWT
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
