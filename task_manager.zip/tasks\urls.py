from django.urls import path
from . import views
from .views import task_list, task_add, task_edit, task_delete, pause_task, resume_task

urlpatterns = [
    path('', views.task_list, name='task_list'),
    path('add/', views.task_add, name='task_add'),
    path('edit/<int:pk>/', views.task_edit, name='task_edit'),
    path('delete/<int:task_id>/', views.task_delete, name='task_delete'),
    path('task/<int:task_id>/pause/', pause_task, name='task_pause'),
    path('task/<int:task_id>/resume/', resume_task, name='task_resume'),
    path('api/users/', views.user_list_api, name='user_list_api'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
]
