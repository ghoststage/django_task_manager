from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from .models import Task
from datetime import date

class TaskModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')

    def test_create_task(self):
        task = Task.objects.create(
            title='Тестовая задача',
            description='Описание тестовой задачи',
            owner=self.user,
            deadline=date.today()
        )
        self.assertEqual(str(task), 'Тестовая задача')
        self.assertEqual(task.status, 'open')
        self.assertFalse(task.pause_comment)


class TaskViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')
        self.task = Task.objects.create(
            title='Просмотр задачи',
            description='Описание',
            owner=self.user,
            deadline=date.today()
        )

    def test_task_list_view(self):
        response = self.client.get(reverse('task_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Просмотр задачи')

    def test_add_task(self):
        response = self.client.post(reverse('task_add'), {
            'title': 'Новая задача',
            'description': 'Описание задачи',
            'deadline': date.today()
        }, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Новая задача')

    def test_edit_task(self):
        response = self.client.post(reverse('task_edit', args=[self.task.id]), {
            'title': 'Обновлённая задача',
            'description': 'Обновлённое описание',
            'deadline': date.today()
        }, follow=True)
        self.assertEqual(response.status_code, 200)
        self.task.refresh_from_db()
        self.assertEqual(self.task.title, 'Обновлённая задача')

    def test_delete_task(self):
        response = self.client.post(reverse('task_delete', args=[self.task.id]), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Task.objects.filter(id=self.task.id).exists())

    def test_pause_resume_task(self):
        # Pause
        response = self.client.post(reverse('task_pause', args=[self.task.id]), follow=True)
        self.task.refresh_from_db()
        self.assertEqual(self.task.status, 'paused')

        # Resume
        response = self.client.post(reverse('task_resume', args=[self.task.id]), follow=True)
        self.task.refresh_from_db()
        self.assertEqual(self.task.status, 'in_progress')