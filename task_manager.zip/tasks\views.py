from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from .models import Task
from .forms import TaskForm, LoginForm, RegisterForm
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import User
from .serializers import TaskSerializer, UserSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework import viewsets
from django.urls import reverse
from django.http import JsonResponse
from django.views.decorators.http import require_POST




class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect('task_list')
            else:
                form.add_error(None, 'Invalid username or password')
    else:
        form = LoginForm()
    return render(request, 'tasks/login.html', {'form': form})


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('task_list')
    else:
        form = RegisterForm()
    return render(request, 'tasks/register.html', {'form': form})


@login_required
def task_list(request):
    tasks = Task.objects.filter(owner=request.user) if not request.user.is_superuser else Task.objects.all()
    users = User.objects.all()

    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.owner = request.user
            task.save()
            form.save_m2m()
            return redirect('task_list')
    else:
        form = TaskForm()

    return render(request, 'tasks/task_list.html', {
        'tasks': tasks,
        'form': form,
        'users': users,
    })


@login_required
def task_add(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.owner = request.user
            task.save()
            form.save_m2m()
            return redirect('task_list')
    else:
        form = TaskForm()

    return render(request, 'tasks/task_add.html', {
        'form': form,
        'users': User.objects.all()
    })

@login_required
def task_delete(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.delete()
    return redirect('task_list')


@login_required
def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)
    return render(request, 'tasks/task_edit.html', {'form': form, 'task': task})


@login_required
def pause_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method == 'POST':
        pause_comment = request.POST.get('pause_comment')
        resume_date = request.POST.get('resume_date')

        task.status = "paused"
        task.pause_comment = pause_comment
        task.resume_date = resume_date
        task.save()

    return redirect('task_list')


@login_required
def resume_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if task.status == "paused":
        task.status = "active"
        task.pause_comment = ""
        task.resume_date = None
        task.save()
    return redirect('task_list')


class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            access_token = refresh.access_token
            return Response({
                'user': serializer.data,
                'refresh': str(refresh),
                'access': str(access_token)
            })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        try:
            user = User.objects.get(username=username)
            if user.check_password(password):
                refresh = RefreshToken.for_user(user)
                access_token = refresh.access_token
                return Response({
                    'refresh': str(refresh),
                    'access': str(access_token)
                })
            else:
                return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)


def user_list_api(request):
    users = User.objects.all().values("id", "username")
    return JsonResponse(list(users), safe=False)


@require_POST
def pause_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.status = 'paused'
    task.save()
    return redirect('task_list')

@require_POST
def resume_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.status = 'in_progress'
    task.save()
    return redirect('task_list')